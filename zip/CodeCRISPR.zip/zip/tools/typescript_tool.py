# Uses same logic as JavaScript, but supports access modifiers and types
from tools.javascript_tool import CodeCRISPR

# Alias for backwards compatibility
MethodEditor = CodeCRISPR
